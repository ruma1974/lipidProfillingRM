#' @useDynLib lipidProfillingRM
#' @importFrom Rcpp sourceCpp
#'
NULL

